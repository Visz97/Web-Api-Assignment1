//snippet rce
import React, { Component } from 'react';
import {
  Card,
  CardImg,
  CardText,
  CardBody,
  CardTitle,
  CardSubtitle,
  Button,
  Table,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Col,
  ListGroup,
  ListGroupItem
} from 'reactstrap';

export class CharacterCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false
    };

    this.toggle = this.toggle.bind(this);
  }

  toggle() {
    this.setState({
      modal: !this.state.modal
    });
  }

  render() {
    let {
      character_id,
      name,
      role,
      house,
      school,
      bloodStatus,
      species,
      character_img_url
    } = this.props.character;
    return (
      <div>
        <Table bordered size="sm">
          <thead>
            <tr>
              <th>
                <center>ID</center>
              </th>
              <th>
                <center>Profile</center>
              </th>
              <th>
                <center>Role</center>
              </th>
              <th>
                <center>House</center>
              </th>
              <th>
                <center>BloodStatus</center>
              </th>

              <th>
                <center>Action</center>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={{ width: '20px' }}>{character_id}</td>
              <td style={{ width: '200px' }}>
                <Card style={{ width: '200px', height: '90%' }}>
                  <CardImg
                    onClick={this.toggle}
                    top
                    width="100%"
                    src={character_img_url}
                  />
                  <CardBody>
                    <CardTitle>{name}</CardTitle>
                    <CardSubtitle style={{ color: '#00e600' }}>
                      role
                    </CardSubtitle>
                    <CardText>{role}</CardText>
                  </CardBody>
                </Card>
              </td>
              <td style={{ width: '100px' }}>{role}</td>
              <td style={{ width: '200px' }}>{school}</td>

              <td style={{ width: '500px' }}>{bloodStatus}</td>

              <td>
                {' '}
                <Button
                  color="danger"
                  onClick={() => this.props.removeCharacter(character_id)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          </tbody>

          <Modal
            isOpen={this.state.modal}
            toggle={this.toggle}
            className={this.props.className}
          >
            <ModalHeader toggle={this.toggle}>
              <span style={{ color: 'orange' }}>{name}</span> Species
            </ModalHeader>
            <ModalBody>
              <div class="row">
                <Col sm="4" />
                <Col sm="4">
                  <img
                    style={{ marginLeft: '-30px' }}
                    width="200px"
                    height="200px"
                    src={character_img_url}
                  />
                </Col>
                <Col sm="4" />

                <Col sm="12">
                  <ListGroup style={{ marginLeft: '10px' }}>
                    <ListGroupItem>
                      <b>Species</b>
                    </ListGroupItem>
                    <ListGroupItem
                      style={{
                        fontSize: '12px',
                        textAlign: 'left',
                        height: '100px'
                      }}
                    >
                      {species}
                    </ListGroupItem>
                  </ListGroup>
                </Col>
              </div>
            </ModalBody>
            <ModalFooter>
              <Button color="secondary" onClick={this.toggle}>
                Back
              </Button>
            </ModalFooter>
          </Modal>
        </Table>
      </div>
    );
  }
}

export default CharacterCard;
