const mongoose = require('mongoose');
const db = 'mongodb://assignment:hanhan1993@ds215961.mlab.com:15961/assignment';

mongoose
  .connect(db, { useNewUrlParser: true })
  .then(() => {
    console.log('Connected to database');
  })
  .catch(error => {
    console.log('Mongoose connetion error: ', error);
  });

const schema = mongoose.Schema({
  character_id: { type: Number },
  name: { type: String },
  role: { type: String },
  house: { type: String },
  school: { type: String },
  bloodStatus: { type: String },
  species: { type: String },
  character_img_url: { type: String }
});

const Character = mongoose.model('Character', schema, 'magic');

module.exports = Character;
