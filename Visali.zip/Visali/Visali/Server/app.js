//https://server-visali.herokuapp.com/

const express = require('express');
const app = express();
const axios = require('axios');
const Character = require('./Character');
const cors = require('cors');
const port = process.env.PORT || 2000;

app.use(cors());
app.use(function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept'
  );
  next();
});

const character_img_url = {
  'Albus Dumbledore':
    'https://docs.google.com/uc?id=1u4FerV3WDp_030OqNlfPLRP2CdU1sM7m',

  'Amelia Bones':
    'https://docs.google.com/uc?id=14GtZI2KvA0B5s8hrxxae3PuIozPTV29j',

  'Bathsheda Babbling':
    'https://docs.google.com/uc?id=1zBbdvmg4ZQqVBa9bElDotHjtUI18_ZnK',

  'Hannah Abbott':
    'https://docs.google.com/uc?id=1sDzKhuH4NUQpRk-dqT4clojZF8wSTFVF',

  'Harry Potter':
    'https://docs.google.com/uc?id=1Bt8iMBwClulMr9rjk5DktmK0BMs9elKR',

  'Hermione Granger':
    'https://docs.google.com/uc?id=1nbXfZbXH6QEpWUJZ4FntG0Ot9Bzd_6o1',

  'James Potter I':
    'https://docs.google.com/uc?id=1EVn6hBHt26-GIINQvCbMQgkfF2DG90ry',

  'Katie Bell':
    'https://docs.google.com/uc?id=1O4Oi81hWuQbHr8Vp_NIUvWX0Ft2dS1YS',

  'Lavender Brown':
    'https://docs.google.com/uc?id=1mdf7fd0dfCfpaY1eoLzt0W-E7nLfo2UK',

  'Regulus Black':
    'https://docs.google.com/uc?id=1xKSwmcQAwtB6b4RgveYX2nLqrrBPj42b',

  'Remus Lupin':
    'https://docs.google.com/uc?id=15njB2MsdyKdeoH18lhMPYzxJi4-U_Hqy',

  'Ronald Weasley':
    'https://docs.google.com/uc?id=1hquxQ5rs0Y0-pPboZuwGErf6JWd2EvwI',

  'Severus Snape':
    'https://docs.google.com/uc?id=1mpOQ9FpINX5OiRWGRX_iybk6nNJlSfG5',

  'Sirius Black':
    'https://docs.google.com/uc?id=1GeMv47uSperznNMoV0rkSTRsP83lV4gH'
};

var i = 1;

//http://localhost:2000/personAdd?name=Harry Potter
app.get('/personAdd', (req, res) => {
  const name = req.query.name;
  const querystr = `https://www.potterapi.com/v1/characters?name=${name}&key=$2a$10$WyVOGavgXlJC53K9y5wUueMk8Ze4dBpOF8KkE6VRUCZS95N81p07u`;

  axios
    .get(querystr)
    .then(response => {
      const my_character = new Character({
        character_id: i, //make change
        name: response.data[0].name,
        role: response.data[0].role,
        house: response.data[0].house,
        school: response.data[0].school,
        bloodStatus: response.data[0].bloodStatus,
        species: response.data[0].species,
        character_img_url: character_img_url[name]
      });

      i = i + 1; //make change
      console.log(i);
      if (!my_character.name) {
        res.status(200).json('Not found');
        return;
      }
      my_character
        .save()
        .then(response => {
          res.status(200).json(response);
        })
        .catch(error => {
          res.status(400).json(error);
        });
    })
    .catch(error => {
      res.status(400).json(error);
    });
});

//localhost:2000/personGetAll
app.get('/personGetAll', (req, res) => {
  Character.find({})
    .then(response => {
      res.status(200).send(response);
    })
    .catch(error => {
      res.status(400).send(error);
    });
});

//localhost:2000/personDelete?character_id=character_id
app.get('/personDelete', (req, res) => {
  Character.deleteMany({ character_id: req.query.character_id })
    .then(response => {
      res.status(200).json(response);
    })
    .catch(error => {
      res.status(400).json(error);
    });
});

app.listen(port, () => {
  console.log(`server listening on port ${port}`);
});
